class Item {

    // Fill this in

}

module.exports = {
  Item,
};
