class Item {
	constructor(name, price) {
		this.name = name;
		this.price = price;
	}
}

module.exports = {
	Item
}